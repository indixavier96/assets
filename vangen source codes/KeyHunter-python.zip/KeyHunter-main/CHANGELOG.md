# Changelog

All notable changes to KeyHunter will be documented in this file.


## [1.2.0] - CURRENT

### Added
- Added katana integration for enhanced URL crawling with JavaScript crawling support
- Added `--install` / `--setup` flag for automatic dependency installation (requires sudo)
- Added `-l` / `--urls-file` flag to scan URLs directly from a file (skips domain enumeration)
- Improved httpx error handling with comprehensive error diagnostics
- Enhanced verbose mode to show actual httpx commands and full error output
- URL validation improvements to catch malformed URLs early

### Changed
- Improved dependency checking to only announce missing tools
- Enhanced error messages for better debugging

### Fixed
- Fixed httpx integration issue where errors were not being captured or displayed
- Fixed "Unknown error" messages by properly checking both stdout and stderr
- Fixed dependency installation flow to exit gracefully after successful installation

## [1.1.9] - Previous

### Changed
- Enhanced API key search functionality to eliminate duplicates
- Improved result output formatting

### Added
- Added new API key patterns for JWT and RSA Private Key
- Added React App environment variable pattern

### Fixed
- Refined Firebase and Generic API Key patterns for improved accuracy
- Removed Twitter access token patterns

## [1.1.8] - Previous

### Changed
- Refactored API key storage structure
- Updated result saving logic

## [1.1.7] - Previous

### Changed
- Improved URL fetching by streaming response content

### Added
- Added Shopify API tokens support

## Previous Versions

### Added
- Support for custom headers (X-Request-For)
- Cookie authentication support
- Random User-Agent rotation
- Multiple domain support from file
- Subdomain enumeration with subfinder
- Wayback Machine URL collection
- Asynchronous URL processing
- YAML-based API key pattern configuration

### Changed
- Update process now uses git reset instead of pull
- Improved API token pattern matching

