// =============================================================================
// UltrafastSecp256k1 OpenCL - Batch operations stub
// =============================================================================

#include "secp256k1_opencl.hpp"

namespace secp256k1 {
namespace opencl {

// Batch operations are implemented in opencl_context.cpp

} // namespace opencl
} // namespace secp256k1

