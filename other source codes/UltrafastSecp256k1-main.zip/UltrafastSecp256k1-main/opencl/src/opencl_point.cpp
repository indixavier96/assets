// =============================================================================
// UltrafastSecp256k1 OpenCL - Point operations stub
// =============================================================================

#include "secp256k1_opencl.hpp"

namespace secp256k1 {
namespace opencl {

// Point operations are implemented in opencl_context.cpp

} // namespace opencl
} // namespace secp256k1

