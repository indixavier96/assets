#import <React/RCTBridgeModule.h>

@interface UltrafastSecp256k1 : NSObject <RCTBridgeModule>
@end
